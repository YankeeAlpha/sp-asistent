# 🚀 SP Asistent – Kalendár na celý rok a evidencia absencií

Interná webová a mobilná aplikácia (PWA) pre správu tímu, plánovanie celoročných absencií a zadávanie nedostupnosti zamestnancov priamo z ich smartfónov.

---

## 📋 Hlavné funkcie

### 👤 Pre zamestnancov (mobilné rozhranie):
* **Inštalácia do mobilu (PWA):** Možnosť pridať si aplikáciu priamo na plochu smartfónu (iPhone aj Android) bez potreby App Store / Google Play.
* **Jednoduché prihlásenie:** Zamestnanec si vyberie svoje meno a zadá svoj 4-miestny PIN kód (s možnosťou zapamätať si prihlásenie).
* **Rýchle zadanie neprítomnosti:**
  * 🏖️ **Dovolenka** (celý deň, pol dňa)
  * 🤒 **PN** (Práceneschopnosť)
  * 👶 **OČR** (Ošetrovanie člena rodiny)
  * 🩺 **Lekárska prehliadka / Lekár (P)** (celý deň alebo počet hodín)
  * ⏱️ **Náhradné voľno (NV)**
  * 📁 **Iné voľno**
* **Osobný kalendár a zostatky:** Zamestnanec vidí svoj aktuálny zostatok dovolenky, počet dní PN/OČR a prehľadný mesačný kalendár.

### 👑 Pre vás ako manažéra / správcu:
* **Celoročný kalendár (12 mesiacov):** Všetkých 12 mesiacov na jednej obrazovke s farebnými indikátormi absencií. Kliknutím na ľubovoľný deň sa zobrazí detailný rozpis prítomnosti.
* **Tímový maticový prehľad:** Zamestnanci v riadkoch, dni v mesiaci v stĺpcoch – okamžitý vizuálny prehľad o obsadenosti tímu.
* **Slovenské štátne sviatky a víkendy:** Automatický výpočet sviatkov (vrátane pohyblivej Veľkej noci). Sviatky a víkendy sa automaticky nezapočítavajú do čerpania dovolenky.
* **Zostatky a štatistiky:** Prehľad nároku na dovolenku, vyčerpaných dní, zostatku, počtu dní PN, OČR a návštev lekára.
* **Export do Excelu (CSV):** Jedným kliknutím stiahnete kompletný report s diakritikou (UTF-8 BOM).
* **Správa zamestnancov:** Pridávanie kolegov, nastavovanie ročného nároku na dovolenku, generovanie a úprava ich PIN kódov.
* **Mobilný prístup (QR kód):** Obrazovka s vygenerovaným QR kódom a odkazom pre rýchle načítanie v mobile.

---

## ⚡ Ako aplikáciu spustiť

1. Otvorte priečinok `SP asistent` na ploche.
2. Dvojklikom spustite súbor **`spustit.bat`**.
3. Aplikácia sa automaticky otvorí vo vašom internetovom prehliadači na adrese:
   👉 **`http://localhost:3000`**

---

## 📱 Ako sa zamestnanci pripoja zo svojho mobilu

1. Mobil zamestnanca musí byť pripojený na rovnakú **firemnú Wi-Fi sieť** (alebo hotspot).
2. Po spustení `spustit.bat` uvidíte v čiernom okne presnú IP adresu (napr. `http://192.168.0.22:3000`), prípadne v manažérskom rozhraní kliknite na záložku **„Mobilný prístup (QR)“**.
3. Zamestnanec otvorí túto adresu vo svojom mobilnom prehliadači (alebo naskenuje QR kód).
4. **Pridanie na plochu mobilu:**
   * **iPhone (Safari):** Kliknite dole na tlačidlo **Zdieľať** ⭡ a vyberte **„Pridať na plochu“** (*Add to Home Screen*).
   * **Android (Chrome):** Kliknite vpravo hore na menu **⋮** a vyberte **„Inštalovať aplikáciu“** (*alebo Pridať na plochu*).
5. Aplikácia bude fungovať ako plnohodnotná samostatná ikona na ploche mobilu!

---

## 🔑 Predvolené prihlasovacie údaje

### Manažér / Správca:
* Rola: **Správca / Manažér**
* PIN kód: **`0000`**

### Predvolení zamestnanci (možno zmeniť v Správe zamestnancov):
* **Ján Novák** → PIN: **`1111`**
* **Mária Kováčová** → PIN: **`2222`**
* **Peter Horváth** → PIN: **`3333`**

*(Ďalších zamestnancov môžete kedykoľvek pridať v záložke „Správa zamestnancov“ s ich vlastným menom a PINom).*

---

## 💾 Kde sú uložené dáta?
Všetky údaje sa ukladajú lokálne na vašom počítači do súboru **`data.db`** (databáza SQLite). Dáta sú permanentné, nestratia sa ani po reštarte počítača a dajú sa jednoducho zálohovať skopírovaním súboru `data.db`.
