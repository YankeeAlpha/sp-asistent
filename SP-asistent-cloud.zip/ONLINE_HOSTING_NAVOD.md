# 🚀 Návod: Spustenie aplikácie na VERCEL (100% ZADARMO a BEZ USÍNANIA)

**Vercel** je moderná svetová webová platforma. Na rozdiel od Renderu sa **NIKDY nevypína po 15 minútach**, načítava sa bleskovo za pár milisekúnd a je pre osobné aj firemné použitie **zadarmo**.

---

## Krok 1: Nahratie nových súborov na GitHub (1 minúta)

1. Otvorte váš repozitár: **[github.com/YankeeAlpha/sp-asistent](https://github.com/YankeeAlpha/sp-asistent)**.
2. Kliknite na **Add file** → **Upload files**.
3. Pretiahnite z priečinka `SP asistent` na ploche tieto súbory a priečinky:
   * `server.js`
   * `package.json`
   * `vercel.json`
   * celý priečinok `api` (obsahuje `index.js`)
   * celý priečinok `public` (`app.js`, `index.html`, `styles.css`, `sw.js`)
4. Kliknite na zelené tlačidlo **Commit changes**.

---

## Krok 2: Spustenie na Vercel.com (1 minúta)

1. Otvorte stránku **[vercel.com](https://vercel.com)**.
2. Kliknite na **Sign Up** (alebo **Log In**) a zvoľte **Continue with GitHub** (prihlásenie jedným klikom).
3. Na hlavnej obrazovke kliknite na **Add New...** → zvoľte **Project**.
4. Pri vašom repozitári **`sp-asistent`** kliknite na tlačidlo **Import**.
5. Nič nemeňte v nastaveniach, rovno kliknite na modré tlačidlo **Deploy**.
6. Počkajte cca 30 sekúnd – uvidíte ohňostroj a nápis **Congratulations!**.
   * Vaša nová nonstop webová adresa bude napr.:  
     👉 **`https://sp-asistent-xxxx.vercel.app`**

---

## Krok 3: Pripojenie trvalej databázy (1 klik priamo vo Verceli)

Aby sa dáta nikdy nezmazali, Vercel ponúka bezplatnú PostgreSQL databázu na 1 klik:

1. V prehľade vášho projektu na Verceli kliknite hore na záložku **Storage**.
2. Kliknite na **Create Database** a vyberte **Postgres** (alebo Neon).
3. Kliknite na **Continue** → zadajte názov napr. `sp-asistent-db` → kliknite **Create**.
4. Kliknite na **Connect to Project** (Vercel sám automaticky prepojí `POSTGRES_URL` s vašou aplikáciou – nemusíte nič kopírovať ani nastavovať!).
5. Hotovo!

---

### Výsledok:
* 🟢 **Aplikácia sa NIKDY nevypne** (žiadne 15-minútové usínanie ako na Renderi).
* 🟢 **Dáta sú natrvalo bezpečne uložené v cloude.**
* 🟢 **Blesková rýchlosť** – stránka sa v mobile aj na počítači otvorí do 0.2 sekundy.
* 🟢 **PWA inštalácia:** Zamestnanci si odkaz otvoria na mobile a dajú **„Pridať na plochu“**.
