# 🚀 Návod: Spustenie aplikácie na NETLIFY s Cloud Synchronizáciou (mobil ↔ PC)

Aby sa fotky týždenných rozpisov a dovolenky pridané na **mobile** ihneď zobrazovali aj na **počítači** a u všetkých zamestnancov na rovnakej adrese **`https://sp-asistent.netlify.app`**, je potrebné raz prepojiť Netlify s vaším GitHub repozitárom (Netlify tak zapne vstavaný cloudový server **Netlify Blobs** – úplne zadarmo a bez ďalších účtov).

---

## Krok 1: Nahratie nových súborov na GitHub (1 minúta)

1. Otvorte váš repozitár: **[github.com/YankeeAlpha/sp-asistent](https://github.com/YankeeAlpha/sp-asistent)**.
2. Kliknite na **Add file** → **Upload files**.
3. Rozbaľte balíček **`SP-asistent-cloud.zip`** (nájdete ho v priečinku `SP asistent` na ploche) a pretiahnite jeho obsah na GitHub (`netlify.toml`, `netlify/`, `public/`, `package.json`, `server.js`, `index.html`, `app.js`, `styles.css`, `sw.js`, `manifest.json`).
4. Kliknite na zelené tlačidlo **Commit changes**.

---

## Krok 2: Prepojenie Netlify s GitHubom (bez zmeny adresy!)

1. Otvorte váš projekt na Netlify: **[app.netlify.com/projects/sp-asistent](https://app.netlify.com/projects/sp-asistent)**.
2. Choďte do **Site configuration** (alebo **Project configuration**) → **Build & deploy** → **Continuous deployment** → **Link repository**.
3. Zvoľte **GitHub** a vyberte váš repozitár **`YankeeAlpha/sp-asistent`**.
4. Netlify si automaticky načíta `netlify.toml` a po cca 30 sekundách zverejní novú verziu na rovnakej adrese **`https://sp-asistent.netlify.app/`**.
5. Od tohto momentu svieti v aplikácii zelený stav **`Cloud Sync: OK`** – každá fotka pridaná na mobile sa automaticky do pár sekúnd zobrazí na počítači aj na mobiloch všetkých zamestnancov!

---

## Alternatíva: Ak chcete zostať len pri pretiahnutí ZIP súboru (Netlify Drop)

Ak nechcete prepájať GitHub a nahrávate iba balíček **`SP-asistent-HTML-web.zip`** cez drag-and-drop:
* Fotky sa v aplikácii už zobrazujú ostro, dajú sa otáčať o 90° a posúvať bez orezania.
* Aby sa však zdieľali medzi mobilom a PC bez GitHubu, stačí si založiť bezplatnú databázu na [console.firebase.google.com](https://console.firebase.google.com) (Realtime Database) a jej adresu vložiť v aplikácii do tlačidla **„☁️ Zapnúť synchronizáciu“** v sekcii *Týždenné rozpisy*.
