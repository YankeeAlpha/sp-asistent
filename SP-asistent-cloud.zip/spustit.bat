@echo off
cd /d "%~dp0"
chcp 65001 >nul
title SP Asistent - Kalendár a Evidencia Absencií
cls

echo ============================================================
echo    SP ASISTENT - EVIDENCIA ABSENCIÍ A KALENDÁR
echo ============================================================
echo.
echo Spúšťam interný server aplikácie...

:: Pokus o spustenie prehliadača po štarte servera
start "" http://localhost:3000

:: Spustenie cez agy-node alebo klasický node
where agy-node >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    agy-node server.js
    goto end
)

where node >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    node server.js
    goto end
)

if exist "%LOCALAPPDATA%\Programs\cursor\resources\app\resources\helpers\node.exe" (
    "%LOCALAPPDATA%\Programs\cursor\resources\app\resources\helpers\node.exe" server.js
    goto end
)

if exist "%APPDATA%\Antigravity\bin\agy-node.cmd" (
    call "%APPDATA%\Antigravity\bin\agy-node.cmd" server.js
    goto end
)

if exist "%LOCALAPPDATA%\Programs\antigravity\Antigravity.exe" (
    set ELECTRON_RUN_AS_NODE=1
    "%LOCALAPPDATA%\Programs\antigravity\Antigravity.exe" server.js
    goto end
)

echo CHYBA: Nepodarilo sa nájsť prostredie Node.js ani agy-node.
pause

:end
